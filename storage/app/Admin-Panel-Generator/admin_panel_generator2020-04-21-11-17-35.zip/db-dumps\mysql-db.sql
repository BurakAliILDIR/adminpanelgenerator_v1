
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `properties` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_log_log_name_index` (`log_name`),
  KEY `subject` (`subject_id`,`subject_type`),
  KEY `causer` (`causer_id`,`causer_type`),
  KEY `activity_log_subject_id_index` (`subject_id`),
  KEY `activity_log_causer_id_index` (`causer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES (1,'default','created','905f7ff3-158b-495a-abf1-ce4108a3ba7f','App\\Models\\User','905f7ce7-3bdf-4d96-bf7f-97e239166c24','App\\Models\\User','{\"attributes\": {\"id\": \"905f7ff3-158b-495a-abf1-ce4108a3ba7f\", \"bio\": null, \"name\": \"Burak Ali\", \"email\": \"burakaliildir@gmail.com\", \"phone\": null, \"gender\": null, \"confirm\": 1, \"surname\": \"ILDIR\", \"password\": \"$2y$10$YpJWWE.fOZGCHYTAAI4Dpe9N/9CXYwBt2nmqdMzp5xYLNrvT0xVYa\", \"date_of_birth\": null, \"remember_token\": null}}','2020-04-20 16:00:29','2020-04-20 16:00:29'),(2,'default','created','905f8373-57ca-4964-9109-c3a6e1ba4207','Modules\\Blog\\Models\\Blog','905f7ff3-158b-495a-abf1-ce4108a3ba7f','App\\Models\\User','{\"attributes\": {\"ad\": \"sad\", \"kasa\": \"2.00\", \"slug\": \"sad\"}}','2020-05-03 20:10:16','2020-04-20 16:10:16'),(3,'default','created','905f98a5-c917-45df-8f22-c059c6abb8e0','App\\Models\\User','905f7ff3-158b-495a-abf1-ce4108a3ba7f','App\\Models\\User','{\"attributes\": {\"id\": \"905f98a5-c917-45df-8f22-c059c6abb8e0\", \"bio\": null, \"name\": null, \"email\": \"123@gmail.com\", \"phone\": null, \"gender\": \"Bay\", \"confirm\": 1, \"surname\": null, \"password\": \"$2y$10$sVAmw867SybSfwchVvSzH.9HTb4.3a/jN3Z6wsYezlJjtZzHqmXX6\", \"date_of_birth\": \"2020-04-20\", \"remember_token\": null}}','2020-04-20 17:09:32','2020-04-20 17:09:32'),(4,'default','created','905faad8-0376-4286-b1c9-9b30c4376b18','App\\Models\\User','905f7ff3-158b-495a-abf1-ce4108a3ba7f','App\\Models\\User','{\"attributes\": {\"id\": \"905faad8-0376-4286-b1c9-9b30c4376b18\", \"bio\": null, \"name\": null, \"email\": \"1234@gmail.com\", \"phone\": null, \"gender\": \"Bay\", \"confirm\": 1, \"surname\": null, \"password\": \"$2y$10$7uTrM13Pxte5guY4Gw7ioeZKVQIY6kkFyu6gb7walQ7NfUMozppBO\", \"date_of_birth\": \"2020-04-20\", \"remember_token\": null}}','2020-04-20 18:00:25','2020-04-20 18:00:25'),(5,'default','created','905fab38-a231-468c-b42c-c05a2de7ad5b','App\\Models\\User','905f7ff3-158b-495a-abf1-ce4108a3ba7f','App\\Models\\User','{\"attributes\": {\"id\": \"905fab38-a231-468c-b42c-c05a2de7ad5b\", \"bio\": null, \"name\": null, \"email\": \"12345@gmail.com\", \"phone\": null, \"gender\": \"Bay\", \"confirm\": 1, \"surname\": null, \"password\": \"$2y$10$oUAFptdnq2gFnYuSRjcmn.ugqm0tK8UHlquXzJYuh8mVQXn8VjyQm\", \"date_of_birth\": \"2020-04-20\", \"remember_token\": null}}','2020-04-20 18:01:29','2020-04-20 18:01:29'),(6,'default','created','905fab82-1550-4a40-bd81-e815cac6e7a9','App\\Models\\User','905f7ff3-158b-495a-abf1-ce4108a3ba7f','App\\Models\\User','{\"attributes\": {\"id\": \"905fab82-1550-4a40-bd81-e815cac6e7a9\", \"bio\": null, \"name\": null, \"email\": \"123456@gmail.com\", \"phone\": null, \"gender\": \"Bay\", \"confirm\": 1, \"surname\": null, \"password\": \"$2y$10$h0iyHgkPStfu7QhUWy0PSOX6EfdPOKWzMuMXmxGSC5a7mrWKbBCmK\", \"date_of_birth\": \"2020-04-20\", \"remember_token\": null}}','2020-04-20 18:02:17','2020-04-20 18:02:17'),(7,'default','created','905fabb3-a040-458f-84ac-bc6281c67c95','App\\Models\\User','905f7ff3-158b-495a-abf1-ce4108a3ba7f','App\\Models\\User','{\"attributes\": {\"id\": \"905fabb3-a040-458f-84ac-bc6281c67c95\", \"bio\": null, \"name\": null, \"email\": \"1234567@gmail.com\", \"phone\": null, \"gender\": \"Bay\", \"confirm\": 1, \"surname\": null, \"password\": \"$2y$10$3s0c.MPFavAx3pJ9VE0WDerjNGp7cRsjs3kqX8O1f5OHg/5IDqfI6\", \"date_of_birth\": \"2020-04-20\", \"remember_token\": null}}','2020-04-20 18:02:49','2020-04-20 18:02:49'),(8,'default','deleted','905fab38-a231-468c-b42c-c05a2de7ad5b','App\\Models\\User','905f7ff3-158b-495a-abf1-ce4108a3ba7f','App\\Models\\User','{\"attributes\": {\"id\": \"905fab38-a231-468c-b42c-c05a2de7ad5b\", \"bio\": null, \"name\": null, \"email\": \"12345@gmail.com\", \"phone\": null, \"gender\": \"Bay\", \"confirm\": 1, \"surname\": null, \"password\": \"$2y$10$oUAFptdnq2gFnYuSRjcmn.ugqm0tK8UHlquXzJYuh8mVQXn8VjyQm\", \"date_of_birth\": \"2020-04-20\", \"remember_token\": null}}','2020-04-20 18:07:12','2020-04-20 18:07:12'),(9,'default','deleted','905faad8-0376-4286-b1c9-9b30c4376b18','App\\Models\\User','905f7ff3-158b-495a-abf1-ce4108a3ba7f','App\\Models\\User','{\"attributes\": {\"id\": \"905faad8-0376-4286-b1c9-9b30c4376b18\", \"bio\": null, \"name\": null, \"email\": \"1234@gmail.com\", \"phone\": null, \"gender\": \"Bay\", \"confirm\": 1, \"surname\": null, \"password\": \"$2y$10$7uTrM13Pxte5guY4Gw7ioeZKVQIY6kkFyu6gb7walQ7NfUMozppBO\", \"date_of_birth\": \"2020-04-20\", \"remember_token\": null}}','2020-04-20 18:07:17','2020-04-20 18:07:17'),(10,'default','deleted','905f98a5-c917-45df-8f22-c059c6abb8e0','App\\Models\\User','905f7ff3-158b-495a-abf1-ce4108a3ba7f','App\\Models\\User','{\"attributes\": {\"id\": \"905f98a5-c917-45df-8f22-c059c6abb8e0\", \"bio\": null, \"name\": null, \"email\": \"123@gmail.com\", \"phone\": null, \"gender\": \"Bay\", \"confirm\": 1, \"surname\": null, \"password\": \"$2y$10$sVAmw867SybSfwchVvSzH.9HTb4.3a/jN3Z6wsYezlJjtZzHqmXX6\", \"date_of_birth\": \"2020-04-20\", \"remember_token\": null}}','2020-04-20 18:07:17','2020-04-20 18:07:17'),(11,'default','created','905fadd2-fa25-4953-a57b-b67be20c2548','App\\Models\\User','905f7ff3-158b-495a-abf1-ce4108a3ba7f','App\\Models\\User','{\"attributes\": {\"id\": \"905fadd2-fa25-4953-a57b-b67be20c2548\", \"bio\": null, \"name\": null, \"email\": \"123211@gmail.com\", \"phone\": null, \"gender\": \"Bay\", \"confirm\": 1, \"surname\": null, \"password\": \"$2y$10$BN0bjdVTYcEowgiwnaWZFOR5lVYsnP7IOy5NQe/PSz8sf2moOx9Wi\", \"date_of_birth\": \"2020-04-20\", \"remember_token\": null}}','2020-04-20 18:08:45','2020-04-20 18:08:45'),(12,'default','created','905fadde-cc16-4a9b-a9aa-a6e171a0383e','App\\Models\\User','905f7ff3-158b-495a-abf1-ce4108a3ba7f','App\\Models\\User','{\"attributes\": {\"id\": \"905fadde-cc16-4a9b-a9aa-a6e171a0383e\", \"bio\": null, \"name\": null, \"email\": \"1123@gmail.com\", \"phone\": null, \"gender\": \"Bay\", \"confirm\": 1, \"surname\": null, \"password\": \"$2y$10$ku7lCYnECATMU.FGljbYYOUly.p77DPWGP94Q5sAdqcPl6TxkYol2\", \"date_of_birth\": \"2020-04-20\", \"remember_token\": null}}','2020-04-20 18:08:53','2020-04-20 18:08:53'),(13,'default','deleted','905fadde-cc16-4a9b-a9aa-a6e171a0383e','App\\Models\\User','905f7ff3-158b-495a-abf1-ce4108a3ba7f','App\\Models\\User','{\"attributes\": {\"id\": \"905fadde-cc16-4a9b-a9aa-a6e171a0383e\", \"bio\": null, \"name\": null, \"email\": \"1123@gmail.com\", \"phone\": null, \"gender\": \"Bay\", \"confirm\": 1, \"surname\": null, \"password\": \"$2y$10$ku7lCYnECATMU.FGljbYYOUly.p77DPWGP94Q5sAdqcPl6TxkYol2\", \"date_of_birth\": \"2020-04-20\", \"remember_token\": null}}','2020-04-20 18:09:00','2020-04-20 18:09:00'),(14,'default','deleted','905fadd2-fa25-4953-a57b-b67be20c2548','App\\Models\\User','905f7ff3-158b-495a-abf1-ce4108a3ba7f','App\\Models\\User','{\"attributes\": {\"id\": \"905fadd2-fa25-4953-a57b-b67be20c2548\", \"bio\": null, \"name\": null, \"email\": \"123211@gmail.com\", \"phone\": null, \"gender\": \"Bay\", \"confirm\": 1, \"surname\": null, \"password\": \"$2y$10$BN0bjdVTYcEowgiwnaWZFOR5lVYsnP7IOy5NQe/PSz8sf2moOx9Wi\", \"date_of_birth\": \"2020-04-20\", \"remember_token\": null}}','2020-04-20 18:09:00','2020-04-20 18:09:00'),(15,'default','created','905fd9a7-a8e1-4603-92b2-bda0b26edf64','App\\Models\\User','905f7ff3-158b-495a-abf1-ce4108a3ba7f','App\\Models\\User','{\"attributes\": {\"id\": \"905fd9a7-a8e1-4603-92b2-bda0b26edf64\", \"bio\": null, \"name\": null, \"email\": \"burak334265@gmail.com\", \"phone\": null, \"gender\": \"Bay\", \"confirm\": 1, \"surname\": null, \"password\": \"$2y$10$lCtCwbu5B3ZBoToUSn9Z5et0v3oScLwhxBCb4QmPNDi36bkDHooNe\", \"date_of_birth\": \"2020-04-20\", \"remember_token\": null}}','2020-04-20 20:11:19','2020-04-20 20:11:19'),(16,'default','updated','905fd9a7-a8e1-4603-92b2-bda0b26edf64','App\\Models\\User','905fd9a7-a8e1-4603-92b2-bda0b26edf64','App\\Models\\User','{\"old\": {\"name\": null}, \"attributes\": {\"name\": \"Ali\"}}','2020-04-21 07:29:04','2020-04-21 07:29:04');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `ad` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kasa` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blog_slug_unique` (`slug`),
  KEY `blog_ad_index` (`ad`),
  KEY `blog_kasa_index` (`kasa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `blog` WRITE;
/*!40000 ALTER TABLE `blog` DISABLE KEYS */;
INSERT INTO `blog` VALUES ('905f8373-57ca-4964-9109-c3a6e1ba4207','sad','2020-04-20 16:10:16','2020-04-20 16:10:16',NULL,'sad',2.00);
/*!40000 ALTER TABLE `blog` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bloguser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bloguser` (
  `User` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Blog` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  KEY `bloguser_user_index` (`User`),
  KEY `bloguser_blog_index` (`Blog`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bloguser` WRITE;
/*!40000 ALTER TABLE `bloguser` DISABLE KEYS */;
/*!40000 ALTER TABLE `bloguser` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `deneme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deneme` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `deneme_slug_unique` (`slug`),
  KEY `deneme_name_index` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `deneme` WRITE;
/*!40000 ALTER TABLE `deneme` DISABLE KEYS */;
/*!40000 ALTER TABLE `deneme` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `denemeblog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `denemeblog` (
  `Deneme` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Blog` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  KEY `denemeblog_deneme_index` (`Deneme`),
  KEY `denemeblog_blog_index` (`Blog`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `denemeblog` WRITE;
/*!40000 ALTER TABLE `denemeblog` DISABLE KEYS */;
INSERT INTO `denemeblog` VALUES ('905f18d2-ba89-4765-be56-9596b2c14228','905f19e6-7f40-46a1-bba1-213a2de216de'),('905f18c8-f250-4075-bcbb-f64931c2c16d','905f19e6-7f40-46a1-bba1-213a2de216de');
/*!40000 ALTER TABLE `denemeblog` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `collection_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` bigint(20) unsigned NOT NULL,
  `manipulations` json NOT NULL,
  `custom_properties` json NOT NULL,
  `responsive_images` json NOT NULL,
  `order_column` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (43,'2014_10_12_100000_create_password_resets_table',1),(44,'2019_08_19_000000_create_failed_jobs_table',1),(45,'2020_03_12_081536_create_media_table',1),(46,'2020_03_24_151259_create_permission_tables',1),(47,'2020_03_25_100858_create_users_table',1),(48,'2020_03_30_122341_create_Blog_table',1),(49,'2020_04_20_103140_create_Deneme_table',1),(50,'2020_04_20_152446_create_activity_log_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
INSERT INTO `model_has_permissions` VALUES (1,'App\\Models\\User','905fd9a7-a8e1-4603-92b2-bda0b26edf64'),(2,'App\\Models\\User','905fd9a7-a8e1-4603-92b2-bda0b26edf64'),(3,'App\\Models\\User','905fd9a7-a8e1-4603-92b2-bda0b26edf64'),(4,'App\\Models\\User','905fd9a7-a8e1-4603-92b2-bda0b26edf64'),(5,'App\\Models\\User','905fd9a7-a8e1-4603-92b2-bda0b26edf64'),(6,'App\\Models\\User','905fd9a7-a8e1-4603-92b2-bda0b26edf64'),(7,'App\\Models\\User','905fd9a7-a8e1-4603-92b2-bda0b26edf64'),(8,'App\\Models\\User','905fd9a7-a8e1-4603-92b2-bda0b26edf64'),(9,'App\\Models\\User','905fd9a7-a8e1-4603-92b2-bda0b26edf64'),(10,'App\\Models\\User','905fd9a7-a8e1-4603-92b2-bda0b26edf64'),(11,'App\\Models\\User','905fd9a7-a8e1-4603-92b2-bda0b26edf64'),(12,'App\\Models\\User','905fd9a7-a8e1-4603-92b2-bda0b26edf64'),(16,'App\\Models\\User','905fd9a7-a8e1-4603-92b2-bda0b26edf64');
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User','905f7ff3-158b-495a-abf1-ce4108a3ba7f'),(2,'App\\Models\\User','905fd9a7-a8e1-4603-92b2-bda0b26edf64');
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'User.index','web','2020-04-20 16:00:29','2020-04-20 16:00:29'),(2,'User.detail','web','2020-04-20 16:00:29','2020-04-20 16:00:29'),(3,'User.create','web','2020-04-20 16:00:29','2020-04-20 16:00:29'),(4,'User.update','web','2020-04-20 16:00:29','2020-04-20 16:00:29'),(5,'User.delete','web','2020-04-20 16:00:29','2020-04-20 16:00:29'),(6,'User.imageUpload','web','2020-04-20 16:00:29','2020-04-20 16:00:29'),(7,'User.imageDelete','web','2020-04-20 16:00:29','2020-04-20 16:00:29'),(8,'Role.index','web','2020-04-20 16:00:29','2020-04-20 16:00:29'),(9,'Role.detail','web','2020-04-20 16:00:29','2020-04-20 16:00:29'),(10,'Role.create','web','2020-04-20 16:00:29','2020-04-20 16:00:29'),(11,'Role.update','web','2020-04-20 16:00:29','2020-04-20 16:00:29'),(12,'Role.delete','web','2020-04-20 16:00:29','2020-04-20 16:00:29'),(13,'Permission.index','web','2020-04-20 16:00:29','2020-04-20 16:00:29'),(14,'Permission.detail','web','2020-04-20 16:00:29','2020-04-20 16:00:29'),(15,'Permission.update','web','2020-04-20 16:00:29','2020-04-20 16:00:29'),(16,'Logs','web','2020-04-20 16:00:29','2020-04-20 16:00:29');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,2),(2,2),(3,2),(4,2),(5,2),(6,2),(7,2),(8,2),(9,2),(10,2),(11,2),(12,2),(16,2);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'super-admin','web','2020-04-20 16:00:29','2020-04-20 16:00:29'),(2,'admin','web','2020-04-20 20:10:12','2020-04-20 20:10:12');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `phone` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `confirm` tinyint(1) NOT NULL DEFAULT '0',
  `email_verified_at` datetime DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_name_index` (`name`),
  KEY `users_surname_index` (`surname`),
  KEY `users_gender_index` (`gender`),
  KEY `users_date_of_birth_index` (`date_of_birth`),
  KEY `users_confirm_index` (`confirm`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('905f7ff3-158b-495a-abf1-ce4108a3ba7f','Burak Ali','ILDIR','burakaliildir@gmail.com','$2y$10$YpJWWE.fOZGCHYTAAI4Dpe9N/9CXYwBt2nmqdMzp5xYLNrvT0xVYa',NULL,NULL,NULL,NULL,1,'2020-04-20 19:00:29',NULL,'2020-04-20 16:00:29','2020-04-20 16:00:29',NULL),('905f98a5-c917-45df-8f22-c059c6abb8e0',NULL,NULL,'123@gmail.com','$2y$10$sVAmw867SybSfwchVvSzH.9HTb4.3a/jN3Z6wsYezlJjtZzHqmXX6',NULL,NULL,'Bay','2020-04-20',1,NULL,NULL,'2020-04-20 17:09:32','2020-04-20 18:07:17','2020-04-20 18:07:17'),('905faad8-0376-4286-b1c9-9b30c4376b18',NULL,NULL,'1234@gmail.com','$2y$10$7uTrM13Pxte5guY4Gw7ioeZKVQIY6kkFyu6gb7walQ7NfUMozppBO',NULL,NULL,'Bay','2020-04-20',1,NULL,NULL,'2020-04-20 18:00:25','2020-04-20 18:07:17','2020-04-20 18:07:17'),('905fab38-a231-468c-b42c-c05a2de7ad5b',NULL,NULL,'12345@gmail.com','$2y$10$oUAFptdnq2gFnYuSRjcmn.ugqm0tK8UHlquXzJYuh8mVQXn8VjyQm',NULL,NULL,'Bay','2020-04-20',1,NULL,NULL,'2020-04-20 18:01:29','2020-04-20 18:07:12','2020-04-20 18:07:12'),('905fab82-1550-4a40-bd81-e815cac6e7a9',NULL,NULL,'123456@gmail.com','$2y$10$h0iyHgkPStfu7QhUWy0PSOX6EfdPOKWzMuMXmxGSC5a7mrWKbBCmK',NULL,NULL,'Bay','2020-04-20',1,NULL,NULL,'2020-04-20 18:02:17','2020-04-20 18:03:19','2020-04-20 18:03:19'),('905fabb3-a040-458f-84ac-bc6281c67c95',NULL,NULL,'1234567@gmail.com','$2y$10$3s0c.MPFavAx3pJ9VE0WDerjNGp7cRsjs3kqX8O1f5OHg/5IDqfI6',NULL,NULL,'Bay','2020-04-20',1,NULL,NULL,'2020-04-20 18:02:49','2020-04-20 18:03:11','2020-04-20 18:03:11'),('905fadd2-fa25-4953-a57b-b67be20c2548',NULL,NULL,'123211@gmail.com','$2y$10$BN0bjdVTYcEowgiwnaWZFOR5lVYsnP7IOy5NQe/PSz8sf2moOx9Wi',NULL,NULL,'Bay','2020-04-20',1,NULL,NULL,'2020-04-20 18:08:45','2020-04-20 18:09:00','2020-04-20 18:09:00'),('905fadde-cc16-4a9b-a9aa-a6e171a0383e',NULL,NULL,'1123@gmail.com','$2y$10$ku7lCYnECATMU.FGljbYYOUly.p77DPWGP94Q5sAdqcPl6TxkYol2',NULL,NULL,'Bay','2020-04-20',1,NULL,NULL,'2020-04-20 18:08:53','2020-04-20 18:09:00','2020-04-20 18:09:00'),('905fd9a7-a8e1-4603-92b2-bda0b26edf64','Ali',NULL,'burak334265@gmail.com','$2y$10$lCtCwbu5B3ZBoToUSn9Z5et0v3oScLwhxBCb4QmPNDi36bkDHooNe',NULL,NULL,'Bay','2020-04-20',1,'2020-04-20 19:00:29',NULL,'2020-04-20 20:11:19','2020-04-21 07:29:04',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

